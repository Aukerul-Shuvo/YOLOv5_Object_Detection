
Shoe Detection - v2 shoedataset
==============================

This dataset was exported via roboflow.ai on December 3, 2021 at 10:32 AM GMT

It includes 25 images.
Shoe are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 640x640 (Stretch)

No image augmentation techniques were applied.


